module.exports=[40580,(a,b,c)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_admin-creado_page_actions_bad17288.js.map