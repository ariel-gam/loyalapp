module.exports=[61887,(a,b,c)=>{}];

//# sourceMappingURL=80b94_AutoTunePro_loyalfood__next-internal_server_app_login_page_actions_fcb7ebb8.js.map