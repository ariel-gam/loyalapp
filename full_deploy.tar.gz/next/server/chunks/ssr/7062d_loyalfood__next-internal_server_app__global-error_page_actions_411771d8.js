module.exports=[83910,(a,b,c)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app__global-error_page_actions_411771d8.js.map