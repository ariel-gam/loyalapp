module.exports=[26908,(e,o,d)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_api_registro_success_route_actions_5715f2e2.js.map