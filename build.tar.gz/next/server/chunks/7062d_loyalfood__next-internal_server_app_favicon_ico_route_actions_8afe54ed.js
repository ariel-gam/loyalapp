module.exports=[95904,(e,o,d)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_favicon_ico_route_actions_8afe54ed.js.map