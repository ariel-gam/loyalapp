var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/d0301_e65ba7c5._.js")
R.c("server/chunks/d0301_next_b9960860._.js")
R.c("server/chunks/d0301_@supabase_supabase-js_dist_index_mjs_cb4ae420._.js")
R.c("server/chunks/[root-of-the-server]__07301238._.js")
R.c("server/chunks/7062d_loyalfood__next-internal_server_app_auth_callback_route_actions_2f597121.js")
R.m(76752)
module.exports=R.m(76752).exports
