globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/90dd2e67181d7b0d.js",
    "static/chunks/c4322724101be491.js",
    "static/chunks/d7bc864b6f031a99.js",
    "static/chunks/60587cb541e0b90b.js",
    "static/chunks/f4b8fe037b05d37e.js",
    "static/chunks/turbopack-b295d2f220c73ba4.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];