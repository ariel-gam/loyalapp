module.exports=[9911,(a,b,c)=>{}];

//# sourceMappingURL=80b94_AutoTunePro_loyalfood__next-internal_server_app_setup_page_actions_54583280.js.map