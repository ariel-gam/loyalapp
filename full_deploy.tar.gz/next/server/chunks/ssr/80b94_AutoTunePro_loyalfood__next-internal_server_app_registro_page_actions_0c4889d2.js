module.exports=[84341,(a,b,c)=>{}];

//# sourceMappingURL=80b94_AutoTunePro_loyalfood__next-internal_server_app_registro_page_actions_0c4889d2.js.map