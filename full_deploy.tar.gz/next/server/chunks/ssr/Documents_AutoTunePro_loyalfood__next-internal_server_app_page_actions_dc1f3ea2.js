module.exports=[19937,(a,b,c)=>{}];

//# sourceMappingURL=Documents_AutoTunePro_loyalfood__next-internal_server_app_page_actions_dc1f3ea2.js.map