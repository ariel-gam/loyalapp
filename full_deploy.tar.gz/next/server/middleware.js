var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]_next_dist_db0236a7._.js")
R.c("server/chunks/[root-of-the-server]__3161670c._.js")
R.m(15383)
module.exports=R.m(15383).exports
