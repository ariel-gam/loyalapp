var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-welcome/route.js")
R.c("server/chunks/[externals]__30090c77._.js")
R.c("server/chunks/[root-of-the-server]__89873f55._.js")
R.c("server/chunks/[root-of-the-server]__4550a186._.js")
R.c("server/chunks/7062d_loyalfood__next-internal_server_app_api_send-welcome_route_actions_6e0cc1e1.js")
R.m(89818)
module.exports=R.m(89818).exports
