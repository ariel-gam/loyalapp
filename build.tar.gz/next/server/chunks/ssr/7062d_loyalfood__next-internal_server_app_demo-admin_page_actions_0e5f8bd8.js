module.exports=[62045,(a,b,c)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_demo-admin_page_actions_0e5f8bd8.js.map