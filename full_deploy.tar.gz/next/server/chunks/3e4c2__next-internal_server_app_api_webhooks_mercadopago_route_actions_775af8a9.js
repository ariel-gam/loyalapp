module.exports=[67143,(e,o,d)=>{}];

//# sourceMappingURL=3e4c2__next-internal_server_app_api_webhooks_mercadopago_route_actions_775af8a9.js.map