
// Mercado Pago Webhook Payment Notification
// Cuando un usuario paga en Mercado Pago, MP enviará una solicitud POST a nuestra URL con los detalles del pago.
// Esta API recibe la notificación, verifica el pago y actualiza la fecha de vencimiento de la suscripción del cliente.

import { NextResponse } from 'next/server';
import { MercadoPagoConfig, Payment } from 'mercadopago';
import { supabase } from '@/lib/supabase';

// Inicializar el cliente de Mercado Pago
// IMPORTANTE: Recuerda agregar tu Access Token en las variables de entorno (.env.local) como MP_ACCESS_TOKEN
const client = new MercadoPagoConfig({ accessToken: process.env.MP_ACCESS_TOKEN! });

export async function POST(request: Request) {
    try {
        // Mercado Pago envía los datos en la query string (o body dependiendo de la configuración)
        // Para notificaciones tipo Webhook "topic=payment", viene el ID en query params
        const url = new URL(request.url);
        const topic = url.searchParams.get('topic') || url.searchParams.get('type');
        const id = url.searchParams.get('id') || url.searchParams.get('data.id');

        if (topic === 'payment' && id) {
            const payment = new Payment(client);
            const paymentInfo = await payment.get({ id });

            if (paymentInfo.status === 'approved') {
                // El pago fue aprobado. Ahora necesitamos saber QUÉ cliente pagó.
                // Usualmente pasamos el 'store_id' o 'user_id' en el campo 'external_reference' al crear la preferencia.
                const storeId = paymentInfo.external_reference;

                if (storeId) {
                    // Fetch Current Settings to merge
                    const { data: currentStore } = await supabase
                        .from('stores')
                        .select('settings')
                        .eq('id', storeId)
                        .single();

                    // Calculamos la nueva fecha de vencimiento (30 días más)
                    const newExpiryDate = new Date();
                    newExpiryDate.setDate(newExpiryDate.getDate() + 30);

                    // Update settings to mark promo as used
                    const updatedSettings = {
                        ...(currentStore?.settings || {}),
                        promo_used: true
                    };

                    const { error } = await supabase
                        .from('stores')
                        .update({
                            trial_ends_at: newExpiryDate.toISOString(),
                            settings: updatedSettings
                        })
                        .eq('id', storeId);

                    if (error) {
                        console.error('Error actualizando suscripción:', error);
                        return NextResponse.json({ status: 'error' }, { status: 500 });
                    }

                    console.log(`Suscripción renovada para tienda ${storeId}`);
                }
            }
        }

        return NextResponse.json({ status: 'success' });
    } catch (error) {
        console.error('Error webhook:', error);
        return NextResponse.json({ status: 'error' }, { status: 500 }); // Devolver 200/201 igual a veces MP lo requiere para no reintentar
    }
}
