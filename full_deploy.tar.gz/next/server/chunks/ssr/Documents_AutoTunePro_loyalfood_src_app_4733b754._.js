module.exports=[71681,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},25504,a=>{"use strict";let b={src:a.i(71681).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Documents_AutoTunePro_loyalfood_src_app_4733b754._.js.map