var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__b2bb06fc._.js")
R.c("server/chunks/d0301_e65ba7c5._.js")
R.c("server/chunks/[root-of-the-server]__89873f55._.js")
R.c("server/chunks/d0301_@supabase_supabase-js_dist_index_mjs_cb4ae420._.js")
R.c("server/chunks/7062d_loyalfood__next-internal_server_app_api_products_route_actions_75af9b84.js")
R.m(34727)
module.exports=R.m(34727).exports
