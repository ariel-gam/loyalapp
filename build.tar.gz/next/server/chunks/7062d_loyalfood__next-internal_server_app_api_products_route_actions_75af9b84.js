module.exports=[78944,(e,o,d)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_api_products_route_actions_75af9b84.js.map