module.exports=[92416,(e,o,d)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_api_send-welcome_route_actions_6e0cc1e1.js.map