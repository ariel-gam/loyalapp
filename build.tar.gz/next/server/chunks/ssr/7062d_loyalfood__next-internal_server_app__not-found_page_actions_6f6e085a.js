module.exports=[90601,(a,b,c)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app__not-found_page_actions_6f6e085a.js.map