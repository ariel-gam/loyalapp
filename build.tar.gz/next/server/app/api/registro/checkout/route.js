var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/registro/checkout/route.js")
R.c("server/chunks/[root-of-the-server]__163a98db._.js")
R.c("server/chunks/d0301_@supabase_supabase-js_dist_index_mjs_cb4ae420._.js")
R.c("server/chunks/[root-of-the-server]__89873f55._.js")
R.c("server/chunks/3e4c2__next-internal_server_app_api_registro_checkout_route_actions_5ceb8b7f.js")
R.m(68811)
module.exports=R.m(68811).exports
