var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/registro/success/route.js")
R.c("server/chunks/[root-of-the-server]__4d5b8d96._.js")
R.c("server/chunks/d0301_@supabase_supabase-js_dist_index_mjs_cb4ae420._.js")
R.c("server/chunks/[root-of-the-server]__89873f55._.js")
R.c("server/chunks/7062d_loyalfood__next-internal_server_app_api_registro_success_route_actions_5715f2e2.js")
R.m(28183)
module.exports=R.m(28183).exports
