module.exports=[70631,(e,o,d)=>{}];

//# sourceMappingURL=7062d_loyalfood__next-internal_server_app_auth_callback_route_actions_2f597121.js.map